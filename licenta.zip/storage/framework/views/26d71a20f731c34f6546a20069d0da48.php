<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-8 mt-8">
        <h1 class="text-3xl font-semibold mb-4 text-center text-white">Coșul de cumpărături</h1>
        <div class="bg-white rounded-lg shadow-lg overflow-hidden p-4">
            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                     role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>
            <?php
                $total = 0;
            ?>
            <?php if($cart): ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <img src="<?php echo e($item['path']); ?>" alt="<?php echo e($item['title']); ?>" class="w-16 h-16 mr-4">
                            <div>
                                <h2 class="text-lg font-semibold"><?php echo e($item['title']); ?></h2>
                                <p class="text-gray-600">Preț: <?php echo e($item['price']); ?> lei</p>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <form action="<?php echo e(route('cart.update')); ?>" method="POST" class="mr-4">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <input type="number" name="quantity" value="<?php echo e($item['quantity']); ?>" min="1"
                                       class="w-12 mr-2">
                                <button type="submit"
                                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded">
                                    Actualizare
                                </button>
                            </form>
                            <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                <button type="submit"
                                        class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded">
                                    Șterge
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php
                        $total += $item['price'] * $item['quantity'];
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="text-center mb-4">
                    <p class="text-xl font-semibold">Total: <?php echo e($total); ?> lei</p>
                </div>
                <div class="flex justify-center items-center mb-4">
                    <form action="<?php echo e(route('cart.empty')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mr-2">Golește
                            coșul
                        </button>
                    </form>
                    <a href="<?php echo e(route('checkout')); ?>"
                       class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2">Checkout</a>
                </div>
            <?php else: ?>
                <p class="text-lg font-semibold mb-2">Coșul de cumpărături este gol.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\licenta\resources\views/cart/index.blade.php ENDPATH**/ ?>