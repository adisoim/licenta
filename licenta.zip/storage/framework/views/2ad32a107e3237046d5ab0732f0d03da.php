<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4 mt-8">
        <div class="bg-white rounded-lg shadow-lg p-8 mb-6 max-w-4xl mx-auto">
            <div class="flex flex-col md:flex-row">
                <div class="md:w-1/4 flex justify-center items-start">
                    <img src="<?php echo e(asset($book->path)); ?>" alt="<?php echo e($book->title); ?>"
                         class="object-contain rounded" style="max-height: 400px;">
                </div>
                <div class="md:w-3/4 md:pl-8">
                    <h2 class="text-3xl font-semibold mb-4"><?php echo e($book->title); ?></h2>
                    <p class="text-gray-600 mb-4"><strong>ISBN:</strong> <?php echo e($book->isbn); ?></p>
                    <p class="text-gray-600 mb-4"><strong>Preț:</strong> <?php echo e($book->price); ?> lei</p>
                    <p class="text-gray-600 mb-4"><strong>Limbă:</strong> <?php echo e($book->language); ?></p>
                    <p class="text-gray-600 mb-4"><strong>Data
                            lansării:</strong> <?php echo e($book->release_date); ?></p>
                    <p class="text-gray-600 mb-4"><strong>Număr de pagini:</strong> <?php echo e($book->pages); ?></p>
                    <p class="text-gray-600 mb-4"><strong>Descriere:</strong> <?php echo e($book->description); ?></p>
                    <form action="<?php echo e(route('cart.add', $book->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full">
                            Adăugă în Coș
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <?php if(auth()->check()): ?>
            <div class="bg-white rounded-lg shadow-lg p-8 mb-6 max-w-4xl mx-auto">
                <h3 class="text-xl font-semibold mb-4">Adaugă o recenzie</h3>
                <form action="<?php echo e(route('reviews.store', $book)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="title" class="block text-gray-700 text-sm font-bold mb-2">Titlu:</label>
                        <input type="text" name="title" id="title" required
                               class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight">
                    </div>
                    <div class="mb-4">
                        <label for="comment" class="block text-gray-700 text-sm font-bold mb-2">Comentariu:</label>
                        <textarea name="comment" id="comment" rows="3" required
                                  class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight"></textarea>
                    </div>
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Adaugă Recenzie
                    </button>
                </form>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow-lg p-8 max-w-4xl mx-auto">
            <h3 class="text-xl font-semibold mb-4">Recenzii</h3>
            <?php $__empty_1 = true; $__currentLoopData = $book->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-b border-gray-200 mb-4 pb-4">
                    <h4 class="font-bold text-lg"><?php echo e($review->title); ?></h4>
                    <p><?php echo e($review->comment); ?></p>
                    <p class="text-sm text-gray-600">Scris de <?php echo e($review->user->name); ?>

                        pe <?php echo e($review->created_at->format('d-m-Y')); ?></p>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $review)): ?>
                        <form action="<?php echo e(route('reviews.destroy', ['review' => $review->id])); ?>"
                              method="POST" class="inline"
                              onsubmit="return confirm('Ești sigur că vrei să ștergi această recenzie?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:text-red-700">Șterge</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-gray-500">Nu există încă recenzii pentru această carte.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\licenta\resources\views/books/show.blade.php ENDPATH**/ ?>